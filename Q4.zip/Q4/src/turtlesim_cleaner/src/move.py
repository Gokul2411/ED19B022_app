#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from math import pow, atan2, sqrt, pi



def update_pose(data):
	global a,b
	pose = data
	a = pose.x
	b = pose.y
def move():
    # Starts a new node
    rospy.init_node('robot_cleaner', anonymous=True)
    velocity_publisher = rospy.Publisher('/turtle2/cmd_vel', Twist, queue_size=10)
    vel_msg = Twist()
    pose_subscriber = rospy.Subscriber('/turtle1/pose',Pose, update_pose)
    data = Pose()
    
    
    #Receiveing the user's input
    print("Let's move your robot")
    speed = 1

    vel_msg.linear.x = abs(speed)
    vel_msg.linear.y = 0
    vel_msg.linear.z = 0
    vel_msg.angular.x = 0
    vel_msg.angular.y = 0
    vel_msg.angular.z = 0

    while not rospy.is_shutdown():

        #Setting the current time for distance calculus
        t0 = rospy.Time.now().to_sec()
        current_distancex = 0

        #Loop to move the turtle in an specified distance
        while(current_distancex < data.x-2):
            #Publish the velocity
            velocity_publisher.publish(vel_msg)
            #Takes actual time to velocity calculus
            t1=rospy.Time.now().to_sec()
            #Calculates distancePoseStamped
            current_distancex = speed*(t1-t0)
        velocity_publisher.publish(vel_msg)
        vel_msg.angular.z = pi/4 
        vel_msg.linear.x = 1
        vel_msg.linear.y = 1
        while (current_distancex <= data.x):
            velocity_publisher.publish(vel_msg)
            #Takes actual time to velocity calculus
            t1=rospy.Time.now().to_sec()
            #Calculates distancePoseStamped
            current_distancex = speed*(t1-t0)
        vel_msg.angular.z = 0
        vel_msg.linear.y = 0
        vel_msg.linear.x = 1
        while(current_distancex <= data.x+4):
            velocity_publisher.publish(vel_msg)
            #Takes actual time to velocity calculus
            t1=rospy.Time.now().to_sec()
            #Calculates distancePoseStamped
            current_distancex = speed*(t1-t0)
        vel_msg.linear.x = 0
      
        
 
if __name__ == '__main__':
    try:
        #Testing our function
        move()
    except rospy.ROSInterruptException: pass
