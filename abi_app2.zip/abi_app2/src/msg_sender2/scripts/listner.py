#!/usr/bin/env python
import rospy
from std_msgs.msg import String
global a
global b
a = "1"
b = "2"

def node1_callback(data):

    #rospy.loginfo(data.data)
    msg1 = data.data
    global a
    a = msg1
  
  

def node2_callback(data):

    #rospy.loginfo(data.data)
    msg2 = data.data
    global b
    b = msg2
    print(a + ":" + b)
  

    
def listener():
    rospy.init_node('listener', anonymous=True)

    rospy.Subscriber("/team_abhiyaan", String, node1_callback)
    rospy.Subscriber("/autonomy", String, node2_callback)
    print(msg1 + msg2)
   

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

if __name__ == '__main__':
     
        msg1 = msg2 = " "
        listener()
        

